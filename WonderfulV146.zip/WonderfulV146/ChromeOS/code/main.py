import random
from dummy import dummy_battle
import time
import pyfiglet
import os
from playsound3 import playsound

base_path = "/mnt/chromeos/MyFiles/Wonderful/ChromeOS/sfx"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_screen()
print("                                         Saturnbox Interactive Presents")
time.sleep(0.7)
print(".")
time.sleep(0.7)
print(".")
time.sleep(0.7)
print(".\n\n")
text = "   WONDERFUL!? Alpha 1.4.5"
centered_banner = pyfiglet.figlet_format(text, font="chunky", width=100, justify="center")
print(centered_banner)
playsound(base_path + "e_s003.wav")
playsound(base_path + "e_s013.wav")
start = input("                                [type (Y) to start type (N) to exit]\n")
playsound(base_path + "e_s001.wav")
if start.lower() == "n":
    exit()
print("This game has no saving feature, if you lose you will have to restart.\n")
name = input("What is your name?\n")
playsound(base_path + "e_s001.wav")
if name == "origin":
    print(">You weren't supposed to do that...")
    playsound(base_path + "static-82172.mp3")
    exit()
if name == "cheats":
    clear_screen()
    print("get aug - gives you a golden aug.\n")
    print("more coming soon.")
    playsound(base_path + "EDM.wav")
    input("press Enter to exit")
    exit()
print(">Nice name kid...\n")
clear_screen()
print("you wake up in your bed what do you do?.\n")
print("(1) get out of bed.\n")
print("(2) stay in bed.\n")
action = input()
has_aug = False
if action == "1":
    print("you get out of bed\n.")
    playsound(base_path + "e_s001.wav")
    print("What do you do?\n")
    print("(1) go outside.\n")
    print("(2) put on clothes.\n")
    action2 = input()
    if action2 == "get aug":
        playsound(base_path + "z01.mp3")
        print("you got the golden AUG!\n")
        print("use the command (fire) to use it.\n")
        playsound(base_path + "gunreload.mp3")
        has_aug = True
        print("What do you do?\n")
        print("(1) go outside.\n")
        print("(2) put on clothes.\n")
        action3 = input()
        action2 = action3
    if action2 == "1":
        print("you walk outside butt naked, people take pictures of your long john.")
        playsound(base_path + "falure.wav")
        end_text = "The End?"
        end_ascii_art = pyfiglet.figlet_format(end_text)
        print(end_ascii_art)
        time.sleep(2)
        exit()
    if action2 == "2":
        clear_screen()
        print("you put on clothes.\n")
        playsound(base_path + "e_s001.wav")
        playsound(base_path + "ring.mp3")
        print("you hear your phone ring, your best friend is calling, do you pick up?\n")
        print("(1) yes.\n")
        print("(2) no.\n")
        Yep = input()
        if Yep == "1":
            playsound(base_path + "e_s001.wav")
            playsound(base_path + "call.mp3")
            print("IF U DONT GET YO STINKY AHH DOWN HERE I ILL SUBJECT U TO DICKEY TORTURE")
            playsound(base_path + "speech2.mp3")
            playsound(base_path + "hang.mp3")
            print("it seemed to be a call from your best friend reminding you about taco night.")
            exit()
        if Yep == "2":
            playsound(base_path + "e_s001.wav")
            print("you don't pick up the phone.\n")
            print("explore the house?\n")
            print("(1) yes.\n")
            print("(2) no.\n")
            explore = input()
            if explore == "1":
                playsound(base_path + "e_s001.wav")
                print("you find a code it reads (7 5 20-1 21 7 ).")
                print(">sorry but ya have to restart :)")
                playsound(base_path + "static-82172.mp3")
                exit()
            if explore == "2":
                clear_screen()
                playsound(base_path + "e_s001.wav")
                print("you don't explore and instead decide to watch TV.")
                playsound(base_path + "stom.mp3")
                print("you eventually feel hungry.")
                print("you remember why your friend called you, it's taco night today, maybe you could grab a taco.\n")
                print("(1) journey to your best friend's house.")
                print("(2) starve to death")
                journey = input()
                if journey == "1":
                    playsound(base_path + "e_s001.wav")
                    print("you don't feel like starving today so your journey to your friend's house.")
                    print("Dummy: hey, before you go let's see if ya know how to fight, these streets are Mean.\n")
                    input("[press enter to start battle]")
                  
                    dummy_battle(has_aug, base_path, clear_screen)

                    exit()
                if journey == "2":
                    print(">you actually must be stupid.")
                    playsound(base_path + "falure.wav")
                    exit()
else:
    print("because you stayed in bed the adventure never happened")
    playsound(base_path + "snore.mp3")
    end_text = "The End?"
    end_ascii_art = pyfiglet.figlet_format(end_text)
    print(end_ascii_art)
    time.sleep(2)
