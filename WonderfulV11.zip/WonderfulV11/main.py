print("you won't see this.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")


print("Saturnbox Presents...\n\n")


import pyfiglet

text = "WONDERFUL!? Alpha 1.1"
centered_banner = pyfiglet.figlet_format(text, font="chunky", width=100, justify="center")
print(centered_banner)

from playsound import playsound
playsound("C:\\WonderfulV11\\sfx\\e_s003.wav")

playsound("C:\\WonderfulV11\\sfx\\e_s013.wav")

start = input("[type (Y) to start type (N) to exit]\n")
playsound("C:\\WonderfulV11\\sfx\\e_s001.wav")


if start.lower() == "n":
   exit()
else:
    print("This game has no saving feature, if you lose you will have to restart.\n")

name = input("What is your name?\n")
playsound("C:\\WonderfulV11\\sfx\\e_s001.wav")

if name == "origin":
   playsound("C:\\WonderfulV11\\sfx\\static-82172.mp3")
   exit()
else:
         print("Nice name kid...\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

print("you wake up in your bed what do you do?.\n")

print("(1) get out of bed.\n")

action = input("(2) stay in bed.\n")


if action == "1":
   print("you get out of bed\n.")
   playsound("C:\\WonderfulV11\\sfx\\e_s001.wav")
   print("What do you do?\n")

   print("(1) go outside.\n")

   action2 = input("(2) put on clothes.\n")
   if action2 == "get aug":
      playsound("C:\\WonderfulV11\\sfx\\z01.mp3")
      print("you got the golden AUG!")
      playsound("C:\\WonderfulV11\\sfx\\gunreload.mp3")
      has_aug = True
   elif action2 == "1":
     print("you walk outside butt naked, people take")
     print("pictures of your long john.")
     playsound("C:\\WonderfulV11\\sfx\\falure.wav")
     end_text = "The End?"
     end_ascii_art = pyfiglet.figlet_format(end_text)
     print(end_ascii_art)
     exit()
   elif action2 == "2":
        print("you put on clothes")
        playsound("C:\\WonderfulV11\\sfx\\e_s001.wav")
   else:
         print("i don't feel like explaining how you failed.")
         playsound("C:\\WonderfulV11\\sfx\\falure.wav")
         exit()     


elif action == "2":
   print("because you stayed in bed the adventure never happened")
   playsound("C:\\WonderfulV11\\sfx\\snore.mp3")
   end_text = "The End?"
   end_ascii_art = pyfiglet.figlet_format(end_text)
   print(end_ascii_art)
   exit()
else:
       print(" I'm gonna assume you picked 2")
       playsound("C:\\WonderfulV11\\sfx\\snore.mp3")
       end_text = "The End?"
       end_ascii_art = pyfiglet.figlet_format(end_text)
       print(end_ascii_art)
       exit()