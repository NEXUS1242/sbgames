import random
import time
from playsound3 import playsound

def dummy_battle(has_aug, base_path, clear_screen):
    enemies = {"Dummy": {"health": 120, "attack": 7}}
    weapons = {"Fists": {"damage": 8}, "AUG": {"damage": 9999}}
    player_health = 100
    if has_aug:
        weapon = weapons["AUG"]
    else:
        weapon = weapons["Fists"]
    enemy_name = "Dummy"
    enemy = enemies[enemy_name]
    enemy_health = enemy["health"]
    crane_kick_uses = 2

    def print_health_bar(label, health, max_health):
        bar_length = 20
        filled = int((max(health, 0) / max_health) * bar_length)
        bar = "[" + "█" * filled + "-" * (bar_length - filled) + "]"
        print(f"{label}: {bar} {max(health, 0)}/{max_health}")

    clear_screen()
    print("ENCOUNTER: " + enemy_name + " approaches!\n")
    while player_health > 0 and enemy_health > 0:
        clear_screen()
        print_health_bar("YOU", player_health, 100)
        print_health_bar(enemy_name, enemy_health, enemy["health"])
        print("""
     ___________________________
    /                           |
   |       [2] DEFEND           |
   |               ▲            | 
   |  [3] ABILITY ◄●► [1] ATTACK|
   |               ▼            |
   |            [4] FIRE        |  
   -----------------------------
""")
        action = input(" ").strip()
        enemy_damage = random.randint(2, 6)

        if action == "1":
            try:
                playsound(base_path + "punch.mp3")
            except Exception:
                print("[Missing punch.mp3 sound]")
            damage = random.randint(1, 9)
            enemy_health -= damage
            print(f"You hit {enemy_name} for {damage} damage!\n")

        elif action == "2":
            print("You brace for incoming attack and take no damage!\n")
            enemy_damage = 0

        elif action == "3":
            print("Choose ability:")
            print("(1) Crane Kick")
            ability_choice = input().strip()
            if ability_choice == "1":
                if crane_kick_uses > 0:
                    try:
                        playsound(base_path + "kick.mp3")
                    except Exception:
                        print("[Missing kick.mp3 sound]")
                    damage = 20
                    enemy_health -= damage
                    print(f"You hit {enemy_name} with Crane Kick for {damage} damage!\n")
                    crane_kick_uses -= 1
                    if enemy_health <= 0:
                        print(f"{enemy_name} defeated!\n")
                        break
                else:
                    print("You have no Crane Kick uses left!\n")
            else:
                print("Invalid ability choice.\n")
                continue

        elif action == "4":
            if has_aug:
                try:
                    playsound(base_path + "gunreload.mp3")
                    playsound(base_path + "fire.mp3")
                except Exception:
                    print("[Missing gun/fire sound]")
                damage = weapons["AUG"]["damage"]
                enemy_health -= damage
                print(f"You fired your AUG at {enemy_name} for {damage} damage!\n")
                if enemy_health <= 0:
                    print(f"{enemy_name} defeated!\n")
                    break
            else:
                print("You don't have a weapon to fire!\n")

        else:
            print("Invalid input.\n")
            continue

        if enemy_health <= 0:
            print(f"{enemy_name} defeated!\n")
            break

        player_health -= enemy_damage
        if enemy_damage > 0:
            print(f"{enemy_name} hits you for {enemy_damage} damage!\n")
        else:
            print(f"{enemy_name} attacks, but you take no damage!\n")
        time.sleep(0.5)

    if player_health <= 0:
        print("You have been defeated!")
    else:
        print("You win!")
        playsound(base_path + "victory.wav")
        time.sleep(2)
