Write-Host "Checking for Python installation..."

$python = Get-Command python -ErrorAction SilentlyContinue

if (-not $python) {
    Write-Host "Python not found. Downloading and installing Python..."
    $installerPath = "$env:TEMP\python-installer.exe"
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe" -OutFile $installerPath
    Start-Process -FilePath $installerPath -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
    Remove-Item $installerPath
    Write-Host "Python installed successfully."
} else {
    Write-Host "Python is already installed."
}

Write-Host "Starting installation of required Python packages..."

python -m ensurepip --upgrade
python -m pip install --upgrade pip
python -m pip install pyfiglet
python -m pip install playsound3

Write-Host "`Installation finished successfully!"
Write-Host "Press Enter to run the program."
Read-Host

cd C:\Wonderful\code

python main.py
